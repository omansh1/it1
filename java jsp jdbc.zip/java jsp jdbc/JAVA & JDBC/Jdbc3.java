import java.sql.*;
import java.util.Scanner;


class Jdbc3
{
	public static void main(String args[])
	{
	Connection cn;
	Statement st;
	try{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		st=cn.createStatement();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter customer's id for the updation in salary");
		int c_id=s.nextInt();
		String query="update customer set salary=salary+1000 where cid="+c_id+" "; 
		int rs=st.executeUpdate(query);
		System.out.println("table updated successfully");
	    }

		catch(ClassNotFoundException e)
		{
			System.out.println("Unable to load driver" +e);
		}
	
		catch(SQLException e)
		{
			System.out.println("Unable to connect"+e);
		}
	}
}

		