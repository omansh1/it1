import java.sql.*;
import java.util.Scanner;

class Jdbc23
{
	public static void main(String args[])
	{
	Connection cn;
	PreparedStatement ps;
	Scanner s=new Scanner(System.in);
	try{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		System.out.println("Enter student's id for the updation of fee");
		int sid=s.nextInt();
		
		String query="update student set sfee=sfee+500 where sid=?";
		ps=cn.prepareStatement(query);
		ps.setInt(1,sid);
		
		int a=ps.executeUpdate();
		System.out.println(+a+"row updated Successfully");
		ps.close();
		
	    }

	catch(ClassNotFoundException e)
	{
		System.out.println("Unable to load driver" +e);
	}
	
	catch(SQLException e)
	{
		System.out.println("Unable to connect"+e);
	}
	}
}


		