import java.sql.*;
import java.util.Scanner;


class Jdbc2
{
	public static void main(String args[])
	{
	Connection cn;
	Statement st;
	try{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		st=cn.createStatement();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter customer's id");
		int cid=s.nextInt();
		System.out.println("Enter customer's name");
		String cname=s.next();
		System.out.println("Enter customer's age");
		int cage=s.nextInt();
		System.out.println("Enter customer's salary");
		float salary=s.nextFloat();
		String query="insert into customer values("+cid+",'"+cname+"',"+cage+","+salary+")"; 
		int rs=st.executeUpdate(query);
		System.out.println(+rs+"row inserted successfully");
	    }

	catch(ClassNotFoundException e)
	{
		System.out.println("Unable to load driver" +e);
	}
	
	catch(SQLException e)
	{
		System.out.println("Unable to connect"+e);
	}
	}
}

		