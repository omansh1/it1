import java.util.Scanner;
import java.util.ArrayList;

interface Stack
{
	void push(int el);
     	int  pop();
     	void display();
}

class StaticStack implements Stack
{ 
  	int top;
	int arr[];
	StaticStack()
	{
		top=-1;
	}
  	StaticStack(int size)
  	{
  		top=-1;
  		arr=new int[size];
  	}
  
  	public void push(int ele)
  	{
		int length=arr.length;

		if(top==length)
  		{
       			System.out.println("STACK OVERFLOW so element cannot be pushed");
     		}
		else
 		{
         		top++;
         		arr[top]=ele; 
     		}
	}
	
  	public int pop()
  	{
     		int popped=-1;
     		if(top==-1)
     		{
        		System.out.println("STACK UNDERFLOW! so element cannot be popped");  
     		}
     		else
     		{
			popped=arr[top];
        		top--;
      		}
		return popped;
   	}
  
	public void display()
   	{
      		if(top==-1)
			System.out.println("STACK IS EMPTY");
      		else
		{
       			System.out.println("CURRENT STACK IS:");
       			for(int i=top;i>=0;i--)
        		{
         			System.out.println(arr[i]);
        		}
		}
	} 
}

class DynamicStack implements Stack
{ 
	ArrayList<Integer> arrd;
  	int top;
	DynamicStack()
  	{
 		top=-1;
  		arrd=new ArrayList<Integer>();
	}
  
  	public void push(int ele)
  	{
	   	int length=arrd.size();
    		top++;
    		arrd.add(top,ele);
      
  	}
  
	public int pop()
   	{
     		int popped=-1;
     		if(top==-1)
     		{
        		System.out.println("STACK UNDERFLOW! so element cannot be popped");  
     		}
     		else
      		{
                	popped=arrd.remove(top);
         		top--;
		}
    		return(popped);
   	}
  
	public void display()
   	{   
     		if(top==-1)
			System.out.println("STACK IS EMPTY");
     		else
		{
     	 		System.out.println("CURRENT STACK IS:");
       			for(int i=arrd.size()-1;i>=0;i--)
        		{
           			System.out.println(arrd.get(i));
        		}
		}
   	}	 
}

class InterfaceStack
 {
    public static void main(String args[])
      { 
         Scanner S=new Scanner(System.in);
         int choice,ch1,ch2;
         do
          {

              System.out.println("***STACK IMPLEMENTATION USING ABSTRACT CLASS STACK***");
              System.out.println("1.Static Stack");
              System.out.println("2. Dynamic Stack");
              System.out.println("3. EXIT");
              choice=S.nextInt(); 
              if(choice==1)
                {
                        System.out.println("Enter the size of array");
                        int size=S.nextInt();

                        StaticStack s1=new StaticStack(size); 

                       	do
           		{
            			System.out.println("STATIC STACK METHODS");
            	        	System.out.println("1.Push an Element");
            		   	System.out.println("2.Pop an Element");
            		   	System.out.println("3.Display Stack");
            		   	System.out.println("4.EXIT From STATIC STACK Menu");
                           	ch1=S.nextInt(); 

                           
                           	if(ch1==1)
                             	{
 					System.out.println("Enter the element to be pushed");
         				int ele=S.nextInt();
        				s1.push(ele);
                                }

  			   	else if(ch1==2)
                             	{
                                	int popped=s1.pop();
                                	if(popped!=-1)
                                	{
 				     		System.out.print("Element popped is:"+popped+"\n");
					} 
			     	}
                           	else if(ch1==3)
                             	{
                                	s1.display();
 				 
			     	}

              		 	}while(ch1!=4);
                 	}

              		else if(choice==2)
                	{     
                     		DynamicStack d1=new DynamicStack(); 
                     		do
           			{
            		   		System.out.println("DYNAMIC STACK METHODS");
            	           		System.out.println("1.Push an Element");
            		   		System.out.println("2.Pop an Element");
            		   		System.out.println("3.Display Stack");
            		   		System.out.println("4.EXIT From DYANMIC STACK Menu"); 
                           		System.out.println("CHOOSE AN OPTION");
                           		ch2=S.nextInt(); 
                         		if(ch2==1)
                             		{
 						System.out.println("Enter the element to be pushed");
         					int ele=S.nextInt();
        					d1.push(ele);
                                
                             		}

  			   		else if(ch2==2)
                           		{
                                		int popped=d1.pop();
                                		if(popped!=-1)
                                		{
 				     			System.out.print("Element Popped is: "+popped+"\n");
						} 
					}
                           		else if(ch2==3)
                           		{
                                		d1.display();
 				 
			     		}

              		 	}while(ch2!=4);

                }
               else
                {
                   System.exit(0);
                } 
            }while(choice!=3);     
          
      }
 }