import java.util.Scanner;

class Rational
{
	 int num;
	 int den;
	
	public Rational()
	{
		num=0;
		den=1;
	}
	
	public Rational(int a, int b)
	{
		num=a;
		den=b;
	}
	
	
	
	public int gcd(int x,int y)
	{
		int rem;
		while(y!=0)
		{
			rem=x%y;
			x=y;
			y=rem;
		}
		return(x);
	}

	

	public void add(Rational r2, Rational r3)
	{
		int val=1;
		num=((r2.num*r3.den)+(r3.num*r2.den));
		den=r2.den*r3.den;
		if(num>den)
			val=gcd(num,den);
		else if(den>num)
			val=gcd(den,num);
		num=num/val;
		den=den/val;
	}
	
	
	public void sub(Rational r2, Rational r3)
	{
		int val=1;
		num=((r2.num*r3.den)-(r3.num*r2.den));
		den=r2.den*r3.den;
		if(num>den)
			val=gcd(num,den);
		else if(den>num)
			val=gcd(den,num);
		num=num/val;
		den=den/val;
	}


	public void mul(Rational r2, Rational r3)
	{
		int val=1;
		num=r2.num*r3.num;
		den=r2.den*r3.den;
		if(num>den)
			val=gcd(num,den);
		else if(den>num)
			val=gcd(den,num);
		num=num/val;
		den=den/val;
	}

	
	public void div(Rational r2, Rational r3)
	{
		int val=1;
		num=r2.num*r3.den;
		den=r2.den*r3.num;
		if(num>den)
			val=gcd(num,den);
		else if(den>num)
			val=gcd(den,num);
		num=num/val;
		den=den/val;
	}
	

	public String toString()
	{
		return(num+"/"+den);
	}
	
}

class Rationalmain
{
	public static void main(String args[])
	{
		Rational r2=new Rational();
		Rational r3=new Rational();
		Rational r1=new Rational();
		int n1,d1,n2,d2;
		Scanner s=new Scanner(System.in);
		String ch="y";
		int choice;
		do
		{
			System.out.println("\n***RATIONAL NUMBERS***");
			System.out.println("1. Enter Rational Numbers");
			System.out.println("2. Addition of Rational Numbers");
			System.out.println("3. Subtraction of Rational Numbers");
			System.out.println("4. Multiplication of Rational Numbers");
			System.out.println("5. Division of Rational Numbers");
			System.out.println("6. EXIT\n");
			
			choice=s.nextInt();
					
			if(choice==1)
			{
				//Rational r1=new Rational();
				System.out.println("Enter the first rational number: num first and then denominator");
				n1=s.nextInt();
				d1=s.nextInt();
				r2=new Rational(n1,d1);			
		
				System.out.println("Enter the second rational number: num first and then denominator");
				n2=s.nextInt();
				d2=s.nextInt();
				r3=new Rational(n2,d2);
			
			System.out.println("\n\nFirst Rational Number:"+r2.toString());
			System.out.println("Second Rational Number:"+r3.toString());
			}

			else if(choice==2)
			{
				//Rational r1=new Rational();
				r1.add(r2,r3);
				System.out.println("\nResult after Addition:"+r1.toString());
			}

			else if(choice==3)
			{
				//Rational r1=new Rational();
				r1.sub(r2,r3);
				System.out.println("\nResult after Subtration:"+r1.toString());
			}

			else if(choice==4)
			{
				//Rational r1=new Rational();
				r1.mul(r2,r3);
				System.out.println("\nResult after Multiplication:"+r1.toString());
			}

			else if(choice==5)
			{
				//Rational r1=new Rational();
				r1.div(r2,r3);
				System.out.println("\nResult after Division:"+r1.toString());
			}
			
			else if(choice==6)
			{
				System.exit(0);
			}
		
			else
			{
				System.out.println("please enter valid choice");
			}

			//System.out.println("DO YOU WANT TO PERFORM ANY OTHER METHOD?(Y/N)");
                     	//ch=s.next();
		}while(ch!="n"||ch=="N");
	}
	
}
	

