import java.util.Scanner;
class Complex
{
	private int real;
	private int img;
	
	public Complex()
	{
		real=0;
		img=0;
	}
	
	public Complex(int a, int b)
	{
		real=a;
		img=b;
	}
	
	
	public void add(Complex c2, Complex c3)
	{
		real=c2.real+c3.real;
		img=c2.img+c3.img;
		
	}
	
	
	public void sub(Complex c2, Complex c3)
	{
		real=c2.real-c3.real;
		img=c2.img-c3.img;
	}


	public void mul(Complex c2, Complex c3)
	{
		real=c2.real*c3.real-c2.img*c3.img;
		img=c2.real*c3.img+c2.img*c3.real;
		

	}

	
	
	public String toString()
	{

		return(real+"+ i"+img);
	}
	
}

class Complexmain
{
	public static void main(String args[])
	{
		Complex c2=new Complex();
		Complex c3=new Complex();
		int r1,i1,r2,i2;
		Scanner s=new Scanner(System.in);
		String ch="y";
		int choice;
		do
		{
			
			System.out.println("\n***COMPLEX NUMBERS***");
			System.out.println("1. Enter Complex Numbers");
			System.out.println("2. Addition of Complex Numbers");
			System.out.println("3. Subtraction of Complex Numbers");
			System.out.println("4. Multiplication of Complex Numbers");
			System.out.println("5. EXIT\n");
			
			choice=s.nextInt();
					
			if(choice==1)
			{
				Complex c1=new Complex();
				System.out.println("Enter the first complex number: real part first and then imaginery part");
				r1=s.nextInt();
				i1=s.nextInt();
				c2=new Complex(r1,i1);			
		
				System.out.println("Enter the second rational number: real part first and then imaginery part");
				r2=s.nextInt();
				i2=s.nextInt();
				c3=new Complex(r2,i2);
			
			System.out.println("\n\nFirst Complex Number:"+c2.toString());
			System.out.println("Second Complex Number:"+c3.toString());
			}

			else if(choice==2)
			{
				Complex c1=new Complex();
				c1.add(c2,c3);
				System.out.println("Result after Addition:"+c1.toString());
			}

			else if(choice==3)
			{
				Complex c1=new Complex();
				c1.sub(c2,c3);
				System.out.println("Result after Subtration:"+c1.toString());
			}

			else if(choice==4)
			{
				Complex c1=new Complex();
				c1.mul(c2,c3);
				System.out.println("Result after Multiplication:"+c1.toString());
			}

						
			else if(choice==5)
			{
				System.exit(0);
			}
		
			else
			{
				System.out.println("please enter valid choice");
			}

			//System.out.println("DO YOU WANT TO PERFORM ANY OTHER METHOD?(Y/N)");
                      //ch=s.next();
		}while(ch!="n"||ch=="N");
	}
	
}	