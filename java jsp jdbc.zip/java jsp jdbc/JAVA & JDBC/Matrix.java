import java.util.Scanner;


class Matrix
{
	int a[][], row,col;
	
	Matrix()
	{
		row=0;
		col=0;
	}
		
	Matrix(int row1, int col1)
	{
		row=row1;
		col=col1;
		a= new int[row][col];
	}
	

	public void input()
	{
		Scanner s=new Scanner(System.in);
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				a[i][j]=s.nextInt();
			}
		}
	}
	

	public void add(Matrix ob1,Matrix ob2)
	{
		if(ob1.row==ob2.row&&ob1.col==ob2.col)
		{
			a=new int[ob1.row][ob1.col];
			row=ob1.row;
			col=ob2.col;
			for(int i=0;i<row;i++)
			{
				for(int j=0;j<col;j++)
				{
					a[i][j]=ob1.a[i][j]+ob2.a[i][j];
				}
			}
			System.out.println("Matrix after Addition is as follows:");
			System.out.println(toString());
		}
		else
			System.out.println("Rows and Cols of matrix are UNEQUAL");

	}

	public void sub(Matrix ob1,Matrix ob2)
	{
		if(ob1.row==ob2.row&&ob1.col==ob2.col)
		{
			a=new int[ob1.row][ob1.col];
			row=ob1.row;
			col=ob2.col;
			for(int i=0;i<row;i++)
			{
				for(int j=0;j<col;j++)
				{
					a[i][j]=ob1.a[i][j]-ob2.a[i][j];
				}
			}
			System.out.println("Matrix after Subtraction is as follows:");
			System.out.println(toString());
		}
		else
			System.out.println("Rows and Cols of matrix are UNEQUAL");

	}

	public void mul(Matrix ob1,Matrix ob2)
	{
		if(ob1.col==ob2.row)
		{
			a=new int[ob1.row][ob2.col];
			row=ob1.row;
			col=ob2.col;
			for(int i=0;i<row;i++)
			{
				for(int j=0;j<col;j++)
				{
					a[i][j]=0;
					for(int k=0;k<ob1.col;k++)
						a[i][j]+=ob1.a[i][k]*ob2.a[k][j];
				}
			}
			System.out.println("Matrix after multiplication is as follows");
			System.out.println(toString());
		}
		else
			System.out.println("ERROR!!! cols of 1st matrix and rows of 2nd matrix are UNEQUAL");
	
	}

	public void trans(Matrix ob1)
	{
		a=new int[ob1.col][ob1.row];
		row=ob1.col;
		col=ob1.row;
		for(int i=0;i<col;i++)
		{
			for(int j=0;j<row;j++)
				a[i][j]=ob1.a[j][i];

		}
	}

	public String toString()
	{
		String str=""; 
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				str+=""+a[i][j]+"";	
			}
			str+="\n";	
		}
		return str;
	}

	public void boolean equals(object o)
	{
			}

}

class Matrixopn
{
	public static void main(String args[])
	{
		int row1,col1,choice;
		Scanner s=new Scanner(System.in);
		Matrix ob1=new Matrix();
		Matrix ob2=new Matrix();
		Matrix ob=new Matrix();
		do
		{
			System.out.println("\n***Choose From the Following Matrix Menu***");
			System.out.println("1.Enter Matrices");
			System.out.println("2.Addition");
			System.out.println("3.Subtraction");
	       		System.out.println("4.Multiplication ");
			System.out.println("5.Transpose of 1st Matrix ");
			System.out.println("6.Transpose of 2nd Matrix ");
			System.out.println("7.Display 1st MATRIX ");
			System.out.println("8.Display 2nd MATRIX ");
			System.out.println("9.Equal Matrix");
			System.out.println("10.EXIT ");
			choice=s.nextInt();
			

			if(choice==1)
			{
				System.out.println("Enter rows and cols of 1st matrix respectively");
				row1=s.nextInt();
				col1=s.nextInt();
				ob1=new Matrix(row1,col1);
				System.out.println("Enter the elements");
				ob1.input();

				System.out.println("Enter rows and cols of 2nd matrix respectively");
				row1=s.nextInt();
				col1=s.nextInt();
				ob2=new Matrix(row1,col1);
				System.out.println("Enter the elements");
				ob2.input();
				
				System.out.println("Matrix1:");
				System.out.println(ob1.toString());
				System.out.println("Matrix2:");
				System.out.println("\n\n"+ob2.toString());
				
			}

			else if(choice==2)
			{
				if(ob1.row==0||ob1.col==0||ob2.row==0||ob2.col==0)
					System.out.println("Error! Enter matrices first then add");
				else
					ob.add(ob1,ob2);
			}
		
			else if(choice==3)
			{
				if(ob1.row==0||ob1.col==0||ob2.row==0||ob2.col==0)
					System.out.println("Error! Enter matrices first then subtract");
				else	
					ob.sub(ob1,ob2);
			}
		
			else if(choice==4)
			{
				if(ob1.row==0||ob1.col==0||ob2.row==0||ob2.col==0)
					System.out.println("Error! Enter matrices first then multiply");
				else
					ob.mul(ob1,ob2);
			}
			else if(choice==5)
			{
				if(ob1.row==0||ob1.col==0)
					System.out.println("Error! Enter matrix then try");
				else
				{	
					ob.trans(ob1);
					System.out.println("Matrix 1 after Transpose is as follows");
					System.out.println(ob.toString());
				}
			}	
			else if(choice==6)
			{
				if(ob2.row==0||ob2.col==0)
					System.out.println("Error! Enter matrix then try");
				else
				{	
					ob.trans(ob2);
					System.out.println("Matrix 2 after Transpose is as follows");
					System.out.println(ob.toString());
				}
			}
			else if(choice==7)
			{
				if(ob1.row==0||ob1.col==0)
					System.out.println("Error! enter matrix then try");
				else
				{
					System.out.println("Matrix1 :");
					System.out.println(ob1.toString());
				}
			}
			else if(choice==8)
			{
				if(ob2.row==0||ob2.col==0)
					System.out.println("Error! Enter matrix then try");
				else
				{	
					System.out.println("Matrix2 :");
					System.out.println(ob2.toString());
				}
			}

			else if(choice==9)
			{
				if(ob1.equals(ob2))
					System.out.println("EQUAL");
				else
					System.out.println("UNEQUAL");
					
				
			}
			else
				System.exit(1);
		}while(choice!=10);
		
	}
}


		