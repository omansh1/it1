import java.sql.*;
import java.util.Scanner;

class Jdbc5
{
	public static void main(String args[])
	{
	Connection cn;
	CallableStatement cs;
	Scanner s=new Scanner(System.in);
	try{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		
		String query="{CALL totalcount(?)}";
		cs=cn.prepareCall(query);
		cs.registerOutParameter(1,Types.INTEGER);
		cs.execute();	
		int countc=cs.getInt(1);
		System.out.println("Total customers are"+countc);
		cs.close();
		
	    }

	catch(ClassNotFoundException e)
	{
		System.out.println("Unable to load driver" +e);
	}
	
	catch(SQLException e)
	{
		System.out.println("Unable to connect"+e);
	}
	}
}



/*
create procedure totalcount(
total out number
)
is
begin
select count(*) into total from customer;
end;
*/

		