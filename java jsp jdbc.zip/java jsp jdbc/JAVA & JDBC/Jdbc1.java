import java.sql.*;

class Jdbc1
{
	public static void main(String args[])
	{
	Connection cn;
	Statement st;
	try{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		st=cn.createStatement();
		String query="create table customer(cid number primary key,cname varchar(12), cage number, salary decimal(10,2))"; 
		int rs=st.executeUpdate(query);
		System.out.println("table created successfully");
	    }

	catch(ClassNotFoundException e)
	{
		System.out.println("Unable to load driver" +e);
	}
	
	catch(SQLException e)
	{
		System.out.println("Unable to connect"+e);
	}
	}
}


		