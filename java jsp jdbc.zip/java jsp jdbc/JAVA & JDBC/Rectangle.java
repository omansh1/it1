import java.util.Scanner;
import java.lang.Math;
class Shape
{
	public double x[]=new double[3];
	public double y[]=new double[3];
	public void getcoord()
	{
		Scanner s=new Scanner(System.in);
		for(int i=0;i<3;i++)
		{
			System.out.print("\nEnter the coordinate(x,y) no. "+(i+1)+":");
			x[i]=s.nextInt();
			y[i]=s.nextInt();
		}
	}
	public void showcoord()
	{
		for(int i=0;i<3;i++)
		{
			System.out.print("\nCoordinate no. "+(i+1)+" is: ("+x[i]+","+y[i]+")");
			
		}
	}
}
class Rect extends Shape
{
	double length,breadth;
	public Rect()
	{
		length=0;
		breadth=0;
	}
	public void showcoord()
	{
		System.out.println("Length is: "+length);
		System.out.println("Breadth is: "+breadth);	
	}
	public void calculate()
	{
		super.getcoord();
		length=((x[1]-x[0])*(x[1]-x[0]))+((y[1]-y[0])*(y[1]-y[0]));
		length=Math.sqrt(length);
		breadth=((x[2]-x[1])*(x[2]-x[1]))+((y[2]-y[1])*(y[2]-y[1]));
		breadth=Math.sqrt(breadth);
	}
}
class Rectangle
{
	public static void main(String args[])
	{
		Shape s;
		Rect r=new Rect();
		r.calculate();
		s=r;
		s.showcoord();
	}
}		 