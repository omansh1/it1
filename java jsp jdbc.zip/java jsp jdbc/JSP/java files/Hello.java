package c3;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;

public class Hello extends SimpleTagSupport
{
	private String name;
	public void setName(String n)
	{
		name=n;
	}

	public void doTag() throws JspException,IOException
	{
		JspWriter out=getJspContext().getOut();
		out.println("Hello "+name);
	}
}