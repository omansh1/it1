package c3;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

public class Reverse extends SimpleTagSupport
{
	private String input="";
	public void setInput(String n)
	{
		int len=n.length();
		for(int i=len-1;i>=0;i--)
		{
			input=input+n.charAt(i);
		}
	
	}
	
	public void doTag() throws JspException,IOException
	{
		JspWriter out=getJspContext().getOut();
		out.println(input);
	}
}