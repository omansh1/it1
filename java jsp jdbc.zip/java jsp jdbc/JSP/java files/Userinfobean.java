package c3;
import java.util.*;
public class Userinfobean
{
	private String userName;
	private String birthDate;
	private String emailAddr;
	private String gender;
	private int luckyNumber;
	private String food[];

	private	boolean userNameValid;
	private	boolean birthDateValid;
	private boolean emailAddrValid;
	private boolean genderValid;
	private boolean luckyNumberValid;
	private boolean foodTypeSelected;
	private boolean pizzaSelectedValid;
	private boolean pastaSelectedValid;
	private boolean chineseSelectedValid;
	private boolean foodValid;
	private boolean valid;
	

	
	public Userinfobean()
	{
		userName=birthDate=emailAddr=gender=null;
		luckyNumber=0;
	}

	public void setUserName(String n)
	{
		userName=n;
	}

	public void setBirthDate(String b)
	{
		birthDate=b;
	}

	public void setEmailAddr(String e)
	{
		emailAddr=e;
	}

	public void setGender(String m)
	{
		gender=m;
	}

	public void setLuckyNumber(int l)
	{
		luckyNumber=l;
	}	

	public void setFood(String f[])
	{
		food= new String[f.length];
		for(int i=0;i<f.length;i++)
			food[i]=f[i];
	}

	public String getUserName()
	{
		return userName;
	}

	public String getBirthDate()
	{
		return birthDate;
	}

	public String getEmailAddr()
	{
		return emailAddr;
	}

	
	public String getGender()
	{
		return gender;
	}

	public int getLuckyNumber()
	{
		return luckyNumber;	
	}
	public String[] getFood()
	{
		return food;
	}

	public boolean isUserNameValid()
	{
		if(userName==null)
			userNameValid=false;
		else
			userNameValid=true;
		return userNameValid;
	}


	public boolean isBirthDateValid()
	{
		if(birthDate!=null)
			birthDateValid=true;
		else
			birthDateValid=false;
		return birthDateValid;
	}

	public boolean isEmailAddrValid()
	{
		if(emailAddr!=null)
			emailAddrValid=true;
		else
			emailAddrValid=false;
		return emailAddrValid;
	}

	public boolean isLuckyNumberValid()
	{
		if(luckyNumber>=1 && luckyNumber<=100)
			luckyNumberValid=true;
		else
			luckyNumberValid=false; 
		return luckyNumberValid;
	}


	public boolean isGenderValid()
	{
		if(gender=="m" || gender=="f")
			genderValid=true;
		else
			genderValid=false;
		return genderValid;
	}
	
	public boolean isPizzaSelectedValid()
	{
		if(isFoodTypeSelected("z"))
			pizzaSelectedValid=true;
		else
			pizzaSelectedValid=false;
		return pizzaSelectedValid;
	}

 	public boolean isPastaSelectedValid()
	{
		if(isFoodTypeSelected("p"))
			pastaSelectedValid=true;
		else
			pastaSelectedValid=false;
		return pastaSelectedValid;
	}

	public boolean isChineseSelectedValid()
	{
		if(isFoodTypeSelected("c"))
			chineseSelectedValid=true;
		else
			chineseSelectedValid=false;
		return chineseSelectedValid;
	}


	public boolean isFoodTypeSelected(String ft)
	{
		boolean selected=false;
		if(food==null)
			return false;
		else
			selected=false;

		for(int i=0;i<food.length;i++)
		{
			if(food[i].equals(ft))
			{
				selected=true;
				break;
			}
		}
		return selected;
			
	}
	
	public boolean isFoodValid()
	{
		if(!isPizzaSelectedValid() && !isPastaSelectedValid() && !isChineseSelectedValid())
			foodValid=false;
		else
			foodValid=true;
		return foodValid;
	}

/*	public boolean isValid()
	{
		if(!isUserNameValid() && !isBirthDateValid() && !isEmailAddrValid() && !isGenderValid() && !isLuckyNumberValid() && !isFoodTypeSelected() && !isPizzaSelectedValid() && !isPastaSelectedValid() && !isChineseSelectedValid() && !isFoodValid())
			valid=false;
		else
			valid=true;
	
		return valid;
	}
*/
}