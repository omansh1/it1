package c3;
import java.util.*;
public class userinfo
{
	private String uname;
	private String birthdate;
	private String emailadd;
	private String gender;
	private String luckyno;
	private String food[];
	private boolean unamevalid;
	private boolean birthdatevalid;
	private boolean emailaddvalid;
	private boolean gendervalid;
	private boolean luckynovalid;
	private boolean foodvalid;
	private boolean pizzaselected,pastaselected,chineseselected;
	public void setUname(String n)
	{
		uname=n;
	}
	public void setBirthdate(String b)
	{
		birthdate=b;
	}
	public void setEmailadd(String e)
	{
		emailadd=e;
	}
	public void setGender(String g)
	{
		gender=g;
	}
	public void setLuckyno(String l)
	{
		luckyno=l;
	}
	public void setFood(String f[])
	{
		for(int i=0;i<f.length;i++)
			food[i]=f[i];
	}
	public String[] getFood()
	{
		return food;
	}
	public String getUname()
	{
		return uname;
	}
	public String getBirthdate()
	{
		return birthdate;
	}
	public String getEmailadd()
	{
		return emailadd;
	}
	public String getGender()
	{
		return gender;
	}
	public String getLuckyno()
	{
		return luckyno;
	}
	public boolean isUnamevalid()
	{
		if(uname.equals(""))
			unamevalid=false;
		else
			unamevalid=true;
		return unamevalid;
	}
	public boolean isBirthdatevalid()
	{
		if(birthdate.equals(""))
			birthdatevalid=false;
		else
			birthdatevalid=true;
		return birthdatevalid;
	}
	public boolean isEmailaddvalid()
	{
		if(emailadd.equals(""))
			emailaddvalid=false;
		else
			emailaddvalid=true;
		return emailaddvalid;
	}
	public boolean isLuckynovalid()
	{
		int lucky=Integer.parseInt(luckyno);
		if(lucky>=1 && lucky<=100)
			luckynovalid=true;
		else
			luckynovalid=false;
		return luckynovalid;
	}
	public boolean isGendervalid()
	{
		if(gender!="m" && gender!="f")
			gendervalid=false;
		else
			gendervalid=true;
		return gendervalid;
	}
	private boolean isFoodTypeSelected(String ft)
	{
		if(food.equals(""))
			return false;
		boolean selected=false;
		for(int i=0;i<food.length;i++)
		{
			if(food[i].equals(ft))
			{
				selected=true;
				break;
			}
		}
		return selected;
	}
	public boolean isPizzaselected()
	{
		if(isFoodTypeSelected("z"))
			pizzaselected=true;
		else
			pizzaselected=false;
		return pizzaselected;
	}
	public boolean isPastaselected()
	{
		if(isFoodTypeSelected("p"))
			pastaselected=true;
		else
			pastaselected=false;
		return pastaselected;
	}
	public boolean isChineseselected()
	{
		if(isFoodTypeSelected("c"))
			chineseselected=true;
		else
			chineseselected=false;
		return chineseselected;
	}
	public boolean isFoodvalid()
	{
		if(!isPizzaselected() && !isPastaselected() && !isChineseselected())
			foodvalid=false;
		else
			foodvalid=true;
		return foodvalid;
	}
}