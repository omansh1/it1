package c3;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

public class Substring extends SimpleTagSupport
{
	private String input="";
	private int start;
	private int end;
	
	public void setStart(int s1)
	{	
		start=s1;
	}

	public void setEnd(int e1)
	{
		end=e1;
	}
	
	public void setInput(String n)
	{
		input=n.substring(s1,e1);
			
	}
	
	public void doTag() throws JspException,IOException
	{
		JspWriter out=getJspContext().getOut();
		out.println(input);
	}
}