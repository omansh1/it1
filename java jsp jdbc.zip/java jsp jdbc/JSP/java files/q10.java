import java.sql.*;
import java.util.Scanner;

class q10
{
	public static void main(String args[])
	{
	Connection cn;
	Statement st;
	try
	{	
		int flag=0;
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		Scanner s=new Scanner(System.in);
		
		
		
		String query="select * from Customer";
		ResultSet rs=st.executeQuery(query);
		boolean test=rs.next();
		if(test==false)
			System.out.println("customer table doesn't exist");
		else
		{
			do{
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getDouble(4));
			}while(rs.next());
			
			System.out.println("Enter customer's id whose salary you want to update");
			int id=s.nextInt();
			
			rs.first();
			while(rs.next())
			{
				if(rs.getInt(1)==id)
				{
					double d1=rs.getDouble(4)+2000;
					rs.updateDouble(4,d1);
					rs.updateRow();
					flag=1;
				}
			
			}
			if(flag==0)
				System.out.println("There is no such customer id exist in resultset");
			else
			{
			rs.first();
			
			do{
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getDouble(4));
			}while(rs.next());
			}
		}
			
	}     
	catch(ClassNotFoundException e)
	{
		System.out.println("Unable to load driver"+e);
	}
	catch(SQLException e)
	{
		System.out.println("Unable to connect"+e);
	}
	}
}