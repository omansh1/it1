package c3;

public class Colorchange
{
	private String name;
	private int age;
	private boolean agetest;
	
	public Colorchange()
	{
		name=null;
		age=0;
		agetest=false;
	}

	public void setName(String n)
	{
		name=n;
	}

	public String getName()
	{
		return name;
	}

	public void setAge(int a1)
	{
		age=a1;
	}

	public int getAge()
	{
		return age;
	}
	
	public boolean isAgetest()
	{
		if(age<30)
			agetest=true;
		else
			agetest=false;
	
		return agetest;
	}
}

 