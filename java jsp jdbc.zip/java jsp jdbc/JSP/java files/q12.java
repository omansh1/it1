import java.sql.*;
import java.util.Scanner;


class Jdbc61
{
	public static void main(String args[])
	{
	Connection cn;
	Statement st;
	try{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		cn=DriverManager.getConnection("Jdbc:Odbc:cust","system","12345");
		st=cn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		Scanner s=new Scanner(System.in);
		String query="select * from student "; 
		ResultSet rs=st.executeQuery(query);
		rs.updateInt(1,1003);
		rs.updateString(2,"Ronit");
		rs.updateDouble(3,2500);
		boolean var=rs.next();
		rs.insertRow();
		while(rs.next())
		{
			int sid=rs.getInt(1);
			String sname=rs.getString(2);
			double sfee=rs.getDouble(3);
			System.out.println(sid+"\t"+sname+"\t"+sfee+"\t");
		}	
			
	    }

		catch(ClassNotFoundException e)
		{
			System.out.println("Unable to load driver" +e);
		}
	
		catch(SQLException e)
		{
			System.out.println("Unable to connect"+e);
		}
	}
}

		