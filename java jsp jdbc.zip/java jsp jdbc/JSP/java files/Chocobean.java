package c3;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

public class Chocobean extends SimpleTagSupport
{
	private String texture;
	public void setTexture(String n)
	{
		texture=n;
	}
		
	public void doTag() throws JspException,IOException
	{
		JspWriter out=getJspContext().getOut();
		if(texture.equals("chewy"))
		out.println("fivestar, barone");
		else if(texture.equals("crunchy"))
		out.println("munch,kitkat");
	}
}